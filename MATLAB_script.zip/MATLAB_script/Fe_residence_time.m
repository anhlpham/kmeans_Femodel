%% Fe budget - control
close all;clear all;clc;

%% load data
tracers = rdmds('PTR',Inf);
Fe = tracers(:,:,:,6);
Fesources = rdmds('Ironsources', Inf);
Fesinks = rdmds('Ironsinks', Inf);
SfcDiag = rdmds('SfcDiag', Inf);
mask = ones(360, 160);
mask(tracers(:,:,1,1)==0)=NaN;
Fesed = Fesources(:,:,:,1);
Ferem = Fesources(:,:,:,2);
Fereb = Fesources(:,:,:,3); % bio-remineralization
Fehydro = Fesources(:,:,:,4);
Feinremin = Fesources(:,:,:,5);
Fedust = SfcDiag(:,:,4);
Fescav = Fesinks(:,:,:,1);
Fesci = Fesinks(:,:,:,2); % inorganic scavenging
Fesco = Fesinks(:,:,:,3); % organic scavenging
Febio = Fesinks(:,:,:,4);
Feloss = Fesinks(:,:,:,5); % hidden mechanism

% %% Dust
% % open the input binary file
% fid=fopen('solfe_PI.bin','r','ieee-be');
% tmp=fread(fid,360*160*12,'float32');
% tmp3d=reshape(tmp,360,160,12);
% fclose(fid);
% Fedust = nanmean(tmp3d,3);
%% load grid formation
x = rdmds('XC');
y = rdmds('YC');
z = rdmds('RC');
dx = rdmds('DXG');
dy = rdmds('DYG');
dz = rdmds('DRF');
da = rdmds('RAC');
hc = rdmds('hFacC');
dz3d = repmat(dz,[360 160 1]);
dv = repmat(da,[1 1 23]).*repmat(dz,[360 160 1]).*hc;


%% Calculate global Fe budget
vol=sum(sum(sum(dv)));
da = repmat(da,[1 1 23]);
globalFe = sum(sum(sum(dv.*Fe))) 
globalFesed = sum(sum(sum(dv.*Fesed)))
globalFehydro = sum(sum(sum(dv.*Fehydro)))
globalFedust = sum(sum((Fedust.*dv(:,:,1))))




